/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Interface;

/**
 *
 * @author User
 */
public interface ConvertirSoles {
    double convertToColombianPesos(double soles);
    double convertToDollars(double soles);
    double convertToBolivares(double soles);
    double convertToPesetas(double soles);
    double convertToFrancs(double soles);
    
}
