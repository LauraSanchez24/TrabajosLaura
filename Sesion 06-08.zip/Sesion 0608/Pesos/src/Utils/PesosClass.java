/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utils;

import Interface.PesosInterface;


/**
 *
 * @author Ambiente 209-2
 */
public class PesosClass implements PesosInterface{
    private static final double DOLLAR_EXCHANGE_RATE = 0.00026; // Cambio ficticio
    private static final double BOLIVAR_EXCHANGE_RATE = 400000.0; // Cambio ficticio
    private static final double SOL_EXCHANGE_RATE = 0.29; // Cambio ficticio
    private static final double PESETA_EXCHANGE_RATE = 0.0078; // Cambio ficticio
    private static final double FRANC_EXCHANGE_RATE = 0.00031; // Cambio ficticio

    @Override
    public double convertToDollars(double pesos) {
        return pesos * DOLLAR_EXCHANGE_RATE;
    }

    @Override
    public double convertToBolivares(double pesos) {
        return pesos * BOLIVAR_EXCHANGE_RATE;
    }

    @Override
    public double convertToSoles(double pesos) {
        return pesos * SOL_EXCHANGE_RATE;
    }

    @Override
    public double convertToPesetas(double pesos) {
        return pesos * PESETA_EXCHANGE_RATE;
    }

    @Override
    public double convertToFrancs(double pesos) {
        return pesos * FRANC_EXCHANGE_RATE;
    }
}
