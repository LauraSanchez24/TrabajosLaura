/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Interface;

/**
 *
 * @author User
 */
public interface Convertir {
    double convertToColombianPesos(double dollars);
    double convertToBolivares(double dollars);
    double convertToSoles(double dollars);
    double convertToPesetas(double dollars);
    double convertToFrancs(double dollars);
    
}
