/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import Interface.Convertir;

/**
 *
 * @author User
 */
public class Implementar implements Convertir{
    private static final double COL_PESO_EXCHANGE_RATE = 3865.0;
    private static final double BOLIVAR_EXCHANGE_RATE = 1907410.0;
    private static final double SOL_EXCHANGE_RATE = 4.0;
    private static final double PESETA_EXCHANGE_RATE = 166.386;
    private static final double FRANC_EXCHANGE_RATE = 0.91;

    @Override
    public double convertToColombianPesos(double dollars) {
        return dollars * COL_PESO_EXCHANGE_RATE;
    }

    @Override
    public double convertToBolivares(double dollars) {
        return dollars * BOLIVAR_EXCHANGE_RATE;
    }

    @Override
    public double convertToSoles(double dollars) {
        return dollars * SOL_EXCHANGE_RATE;
    }

    @Override
    public double convertToPesetas(double dollars) {
        return dollars * PESETA_EXCHANGE_RATE;
    }

    @Override
    public double convertToFrancs(double dollars) {
        return dollars * FRANC_EXCHANGE_RATE;
    }
}
