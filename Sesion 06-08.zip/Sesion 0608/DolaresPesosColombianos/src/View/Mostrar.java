/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View;
import Interface.Convertir;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class Mostrar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Convertir convertir = new Convertir() {
            @Override
            public double convertToColombianPesos(double dollars) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public double convertToBolivares(double dollars) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public double convertToSoles(double dollars) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public double convertToPesetas(double dollars) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public double convertToFrancs(double dollars) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };

        System.out.print("Ingrese la cantidad en dólares: ");
        double dollars = scanner.nextDouble();

        double pesos = convertir.convertToColombianPesos(dollars);
        double bolivares = convertir.convertToBolivares(dollars);
        double soles = convertir.convertToSoles(dollars);
        double pesetas = convertir.convertToPesetas(dollars);
        double francs = convertir.convertToFrancs(dollars);

        System.out.println("Resultado de las conversiones:");
        System.out.println("Colombian Pesos: " + pesos);
        System.out.println("Bolivares: " + bolivares);
        System.out.println("Soles: " + soles);
        System.out.println("Pesetas: " + pesetas);
        System.out.println("Francs: " + francs);

        scanner.close();
    }
    }
    

