/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Interface;

/**
 *
 * @author User
 */
public interface Conversion {
    double convertToColombianPesos(double bolivares);
    double convertToDollars(double bolivares);
    double convertToSoles(double bolivares);
    double convertToPesetas(double bolivares);
    double convertToFrancs(double bolivares);
    
}
