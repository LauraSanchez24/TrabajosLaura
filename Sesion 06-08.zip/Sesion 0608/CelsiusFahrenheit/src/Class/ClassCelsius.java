/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

/**
 *
 * @author Ambiente 209-2
 */
public class ClassCelsius {
     public static double celsiusToFahrenheit(double celsius) {
        return (celsius * 9 / 5) + 32;
    }

    public static void main(String[] args) {
        double celsius = 25.0; // Cambia este valor al que desees convertir
        double fahrenheit = celsiusToFahrenheit(celsius);
        System.out.println(" Celsius es igual a: " + celsius + " Y farenheit es igual a: " + fahrenheit);
    }
    
}
