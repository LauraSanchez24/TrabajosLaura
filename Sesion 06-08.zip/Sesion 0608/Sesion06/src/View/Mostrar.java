/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;
import Entity.ConversionGrados.ConversionGrados;
/**
 *
 * @author Ambiente 209-2
 */
public class Mostrar {
      public static void main(String[] args) {
       ConversionGrados cg = new ConversionGrados();
       cg.CelsiusFahrenheit();
       cg.FahrenheitCelsius();
    }
    
}
